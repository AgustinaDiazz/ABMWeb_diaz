
CREATE DATABASE web2;

CREATE SCHEMA usuarios;

CREATE TABLE usuarios.roles(
	id SERIAL PRIMARY KEY,
	rol VARCHAR(50) NOT NULL
);


CREATE TABLE usuarios.usuarios(
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(50) NOT NULL,
	apellido VARCHAR(50) NOT NULL,
	alias VARCHAR(25) UNIQUE NOT NULL,
	contrasenia VARCHAR(25) NOT NULL,
    email_principal VARCHAR(50) UNIQUE NOT NULL,
    email_secundario VARCHAR(50) NOT NULL,
	nro_celular NUMERIC NOT NULL,
	tipo_de_usuario INTEGER REFERENCES usuarios.roles(id) NOT NULL,
	fecha_alta DATE NOT NULL,
	fecha_baja DATE NULL
);


INSERT INTO usuarios.roles (rol) VALUES
	('Administracion'),
	('Sistema');


INSERT INTO usuarios.usuarios (nombre, apellido, alias, contrasenia, email_principal, email_secundario, nro_celular, tipo_de_usuario, fecha_alta, fecha_baja)
VALUES
('Agustina', 'Diaz', 'aguusDiaz', 'Agust123', 'agus@gmail.com', 'diaz@gmail.com', 2804569885, 1, '2023-11-06', NULL),
('pepe', 'perez', 'pePerez', 'Pep123456', 'pepe@gmail.com', 'perez@gmail.com', 2804569332, 2, '2023-11-06', NULL);


