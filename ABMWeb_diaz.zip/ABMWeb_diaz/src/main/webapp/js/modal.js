var context = window.location.pathname.split('/')[1];
//Funcion para crear un usuario
function crear(){
//  $("#modificar").click(function(event) {
  //  event.preventDefault(); // Previene el envío del formulario por defecto

    // Captura los valores de los campos de entrada
    var nombre = $("input[name='nombre']").val();
    var apellido = $("input[name='apellido']").val();
    var alias = $("input[name='alias']").val();
    var emailPrincipal = $("input[name='email_principal']").val();
    var contrasenia = $("input[name='contrasenia']").val();
    var emailSecundario = $("input[name='email_secundario']").val();
    var numeroCelular = $("input[name='nro_celular']").val();
    var tipoUsuario = $("#tipo").val(); // El valor del select

    var parametros='?nombre='+nombre+'&apellido='+apellido+'&alias='+alias+'&email_principal='+emailPrincipal+'&contrasenia='+contrasenia+'&email_secundario='+emailSecundario+'&nro_celular='+numeroCelular+'&tipo='+tipoUsuario;

    // Realiza la solicitud AJAX para crear un usuario
    $.ajax({
        url: 'crear'+parametros,
        type: 'POST', // Especifica el método POST
        success: function(data) {
            // Muestra una notificación de éxito y recarga la página
            Swal.fire({
                title: 'Operacion exitosa',
                text: 'El usuario '+alias+' ha sido creado',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(function () {
                 window.location.href = '../listado'; // Recargar la página
            });
        },
        error: function(xhr, status, error) {
        //Maneja errores y muestra un mensaje de error si la solicitud no tiene éxito
                    var errorMessage = "Ocurrio un error desconocido.";

                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error; // Supongamos que el servidor envía un mensaje de error en JSON.
                    }

                    Swal.fire({
                        title: 'Error',
                        text: 'Causa: '+errorMessage,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
    });
  };
//Función para modificar un usuario
function modificar(){

    // Captura los valores de los campos de entrada
    var id = $("input[name='id']").val();
    var nombre = $("input[name='nombre']").val();
    var apellido = $("input[name='apellido']").val();
    var alias = $("input[name='alias']").val();
    var emailPrincipal = $("input[name='email_principal']").val();
    var contrasenia = $("input[name='contrasenia']").val();
    var emailSecundario = $("input[name='email_secundario']").val();
    var numeroCelular = $("input[name='nro_celular']").val();
    var tipoUsuario = $("#tipo").val(); // El valor del select

    var parametros='?id='+id+'&nombre='+nombre+'&apellido='+apellido+'&alias='+alias+'&email_principal='+emailPrincipal+'&contrasenia='+contrasenia+'&email_secundario='+emailSecundario+'&nro_celular='+numeroCelular+'&tipo='+tipoUsuario;

    // Realiza la solicitud AJAX
    $.ajax({
        url: 'modificar'+parametros,
        type: 'PUT', // Especifica el método PUT
        success: function(data) {
            Swal.fire({
                title: 'Operacion exitosa',
                text: 'El usuario '+alias+' ha sido modificado',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(function () {
                 window.location.href = '../listado'; // Recargar la página
            });
        },
        error: function(xhr, status, error) {
                  // Maneja errores
                    var errorMessage = "Ocurrio un error desconocido.";

                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error; // Supongamos que el servidor envía un mensaje de error en JSON.
                    }

                    Swal.fire({
                        title: 'Error',
                        text: 'Causa: '+errorMessage,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
    });
  };


    
// Función para eliminar un usuario
function eliminar(id){
    Swal.fire({
        title:"¿Desea eliminar al usuario?",
        text:"No se podran recuperar los datos luego de esto.",
        icon:"warning",
        showCancelButton: true,
        confirmButtonText: 'Eliminar',
        cancelButtonText: 'Volver',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            var ruta="../../"+ context +"/listado/borrar/"+id;
            $.ajax({
                url:ruta,
                type:"DELETE",
                success:function(data){
                    Swal.fire({
                        title: 'Operacion exitosa',
                        text: 'El usuario '+data+' ha sido eliminado',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(function () {
                        location.reload(); // Recargar la página
                    });
                },
                error: function(xhr, status, error) {
                  // Maneja errores
                    var errorMessage = "Ocurrio un error desconocido.";

                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error; // Supongamos que el servidor envía un mensaje de error en JSON.
                    }

                    Swal.fire({
                        title: 'Error',
                        text: errorMessage,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            });
        } else if (
            
            result.dismiss === Swal.DismissReason.cancel
        ) {
            Swal.fire(
                'Operacion cancelada.',
                'Los datos del usuario estan a salvo :)',
                'error'
            )
        }
    })
};

// Función para eliminar un usuario y redirigir a una página de listado
function eliminarV(id){
    Swal.fire({
        title:"¿Desea eliminar al usuario?",
        text:"No se podran recuperar los datos luego de esto.",
        icon:"warning",
        showCancelButton: true,
        confirmButtonText: 'Eliminar',
        cancelButtonText: 'Volver',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            var ruta="borrar/"+id;
            $.ajax({
                url:ruta,
                type:"DELETE",
                success:function(data){
                    Swal.fire({
                        title: 'Operacion exitosa',
                        text: 'El usuario '+data+' ha sido eliminado',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(function () {
                        window.location.href = '../listado'; // Recargar la página
                    });
                },
                error: function(xhr, status, error) {
                  // Maneja errores
                    var errorMessage = "Ocurrio un error desconocido.";

                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error; // Supongamos que el servidor envía un mensaje de error en JSON.
                    }

                    Swal.fire({
                        title: 'Error',
                        text: errorMessage,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            });
        } else if (
            result.dismiss === Swal.DismissReason.cancel
        ) {
            Swal.fire(
                'Operacion cancelada.',
                'Los datos del usuario estan a salvo :)',
                'error'
            )
        }
    })
};