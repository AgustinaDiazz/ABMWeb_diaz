/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.models;

import app.exceptions.DatoInvalidoException;
import java.util.List;
import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.Table;

/**
 *
 * @author agus
 */
@Table("usuarios.roles")
public class Rol extends Model {
    
      public static List<Rol> listar(){
        List<Rol> roles = Rol
                .findAll();
        return roles;
    }
    public Rol() {
    }
    
public static void validarRol(int id) throws DatoInvalidoException{
        //valida la existencia de un usuario en la base de datos
        Rol rol = Rol.findById(id);
        if (rol == null) {
            throw new DatoInvalidoException("El usuario con id el " + id + " no existe.");
        }
    }
}
