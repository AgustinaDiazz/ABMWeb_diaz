/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.models;

import java.time.LocalDate;
import java.util.List;
import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.BelongsTo;
import org.javalite.activejdbc.annotations.Table;
import app.exceptions.DatoInvalidoException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author agus
 */
@Table("usuarios.usuarios")
@BelongsTo(foreignKeyName = "tipo_de_usuario", parent = Rol.class)
public class Usuario extends Model {
    
    //Método para obtener una lista de usuarios
    public static List<Usuario> listar(){
        List<Usuario> usuarios = Usuario
                .findAll()
                .include(Rol.class);
        return usuarios;
    }
    //Método para obtener un usuario por su ID
    public static Usuario obtenerUsuario(String id){
        int uid= Integer.parseInt(id);
        Usuario aux = Usuario.findById(uid);
        return aux;
    }
    //Método para obtener el rol de un usuario
    public Rol getRol(){
        return parent(Rol.class);
    }
    public Usuario() {
    }
    
    
    //valida que un string solo tenga letras
    public static boolean validarLetras(String cadena) {
        // Usamos una expresión regular para verificar si solo contiene letras
        return cadena.matches("^[a-zA-Z\\s]+$");
    }
    
    //valida que el email cumpla con el formato algo@algo.algo
    public static boolean validarEmail(String email) {
        // Utilizamos una expresión regular para verificar el formato del email
        String patronEmail = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(patronEmail);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    //valida que la contrasenia contenga una minuscula, una mayuscula, un numero y una minuscula
    public static boolean validarContrasenia(String contrasenia) {
        // Utilizamos una expresión regular para verificar la contraseña
        String patronContrasenia = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d).+$";
        Pattern pattern = Pattern.compile(patronContrasenia);
        Matcher matcher = pattern.matcher(contrasenia);
        return matcher.matches();
    }
    
    //validar longitud maxima de un dato
    public static boolean validarLongitud(String cadena, int longitudDeseada) {
        return cadena.length() <= longitudDeseada;
    }

    //validar longitud minima de un dato
    public static boolean validarLongitudMin(String cadena, int longitudDeseada) {
        return cadena.length() >= longitudDeseada;
    }
    
    //Valida que la longitud de un número largo no sea mayor que la longitud deseada
    public static boolean validarLongitudLong(long numero, int longitudDeseada) {
        String numeroComoCadena = Long.toString(numero); // Convierte el número long a una cadena
        return numeroComoCadena.length() <= longitudDeseada;
    }
    
    //Valida que la longitud de un número largo no sea menor que la longitud deseada
    public static boolean validarLongitudLongMin(long numero, int longitudDeseada) {
        String numeroComoCadena = Long.toString(numero); // Convierte el número long a una cadena
        return numeroComoCadena.length() >= longitudDeseada;
    }
    
    //Método para validar datos antes de la creación de un usuario............
    public static boolean validarAlias(String alias) {
        return alias.matches(".*\\s+.*");
    }
    

    //metodo que valida la longitud maxima de cada dato
    public static void validarLongitudMaxContenido(String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular) throws DatoInvalidoException {
        if (!validarLongitud(nombre, 50)) {
            throw new DatoInvalidoException("El nombre no debe tener una longitud superior a 50 caracteres.");
        } 
        if (!validarLongitud(apellido, 50)) {
            throw new DatoInvalidoException("El apellido no debe tener una longitud superior a 50 caracteres.");
        } 
        if (!validarLongitud(emailP, 50)) {
            throw new DatoInvalidoException("El email principal no debe tener una longitud superior a 50 caracteres.");
        } 
        if (!validarLongitud(emailS, 50)) {
            throw new DatoInvalidoException("El email secundario no debe tener una longitud superior a 50 caracteres.");
        } 
        if (!validarLongitud(alias, 25)) {
            throw new DatoInvalidoException("El alias no debe tener una longitud superior a 25 caracteres.");
        } 
        if (!validarLongitud(contrasenia, 50)) {
            throw new DatoInvalidoException("La contrasenia no debe tener una longitud superior a 25 caracteres.");
        } 
        if (!validarLongitudLong(celular, 15)) {
            throw new DatoInvalidoException("El celular no debe tener una longitud superior a 15 caracteres.");
        } 
    }

    //metodo que valida la longitud minima de cada dato
    public static void validarLongitudMinContenido(String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular) throws DatoInvalidoException {
        if (!validarLongitudMin(nombre, 2)) {
            throw new DatoInvalidoException("El nombre no debe tener una longitud inferior a 2 caracteres.");
        } 
        if (!validarLongitudMin(apellido, 2)) {
            throw new DatoInvalidoException("El apellido no debe tener una longitud inferior a 2 caracteres.");
        } 
        if (!validarLongitudMin(emailP, 8)) {
            throw new DatoInvalidoException("El email principal no debe tener una longitud inferior a 8 caracteres.");
        } 
        if (!validarLongitudMin(emailS, 8)) {
            throw new DatoInvalidoException("El email secundario no debe tener una longitud una longitud inferior a 8 caracteres.");
        } 
        if (!validarLongitudMin(alias, 3)) {
            throw new DatoInvalidoException("El alias no debe tener una longitud inferior a 3 caracteres.");
        } 
        if (!validarLongitudMin(contrasenia, 8)) {
            throw new DatoInvalidoException("La contrasenia no debe tener una longitud inferior a 8 caracteres.");
        } 
        if (!validarLongitudLongMin(celular, 8)) {
            throw new DatoInvalidoException("El celular no debe tener una longitud inferior a 8 caracteres.");
        } 
    }


    //metodo que valida el contenido de los datos
    public static void validarContenido(String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular, int tipoUsuario) throws DatoInvalidoException {
        if (!validarLetras(nombre)) {
            throw new DatoInvalidoException("El nombre solo debe tener letras.");
        } 
        if (!validarLetras(apellido)) {
            throw new DatoInvalidoException("El apellido solo debe tener letras.");
        }
        if (!validarEmail(emailP)) {
            throw new DatoInvalidoException("El email principal no cumple con el formato de direcciones de email.");
        } 
        if (!validarEmail(emailS)) {
            throw new DatoInvalidoException("El email secundario no cumple con el formato de direcciones de email.");
        } 
        if (!validarContrasenia(contrasenia)) {
            throw new DatoInvalidoException("La contrasenia debe contener una letra mayuscula, una minuscula y un numero.");
        }  
        if (validarAlias(alias)) {
            throw new DatoInvalidoException("El alias no debe tener espacios en blanco.");        
        } 
        //validar que exista el rol en la base de datos
        Rol.validarRol(tipoUsuario);
    
    }
    
    
    //Método para validar datos del formulario creacion y modificacion de usuario
    public static void validar(String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular, int tipoUsuario) throws DatoInvalidoException {
        //validar longitudes maximas de los campos
        validarLongitudMaxContenido(nombre, apellido, alias, emailP, emailS, contrasenia, celular);
        //validar longitud minima de los campos
        validarLongitudMinContenido(nombre, apellido, alias, emailP, emailS, contrasenia, celular);
        //validaciones contenido de los campos
        validarContenido(nombre, apellido, alias, emailP, emailS, contrasenia, celular, tipoUsuario);
    }
    
    //Método para validar la existencia de un usuario en la base de datos antes de modificarlo
    public static void validarUsuario(int id) throws DatoInvalidoException{
        //valida la existencia de un usuario en la base de datos
        Usuario usuario = Usuario.findById(id);
        if (usuario == null) {
            throw new DatoInvalidoException("El usuario con id el " + id + " no existe.");
        }
    }
    
    //Método para crear un nuevo usuario
    public static void crear (String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular, int tipoUsuario) {
        LocalDate fechaActual = LocalDate.now();
        Usuario p = Usuario.create("nombre", nombre, "apellido", apellido, "alias", alias, "contrasenia", contrasenia, "email_principal", emailP, "email_secundario", emailS, "nro_celular", celular, "tipo_de_usuario", tipoUsuario, "fecha_alta", fechaActual);
        p.saveIt();

    }
    
    //Método para modificar un usuario existente
    public static void modificar(int id, String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular, int tipoUsuario) {
        Usuario usuario = Usuario.findById(id);
        usuario.set("nombre", nombre)
                .set("apellido", apellido)
                .set("alias", alias)
                .set("contrasenia", contrasenia)
                .set("email_principal", emailP)
                .set("email_secundario", emailS)
                .set("nro_celular", celular)
                .set("tipo_de_usuario", tipoUsuario);
        //create("nombre", nombre, "apellido", apellido, "alias", alias, "contrasenia", contrasenia, "email_principal", emailP, "email_secundario", emailS, "nro_celular", celular, "tipo_de_usuario", tipoUsuario, "fecha_alta", fechaActual);
        usuario.saveIt();
    
    }
      //Método para eliminar un usuario
      public static void borrar(int id) {
        Usuario usuario = Usuario.findById(id);
        Usuario.delete("id = ?", id);
   
    }
    
      //Método para obtener el alias de un usuario por su ID
      public static String getAlias(int id){
        Usuario usuario = Usuario.findById(id);
        return usuario.getString("alias");
    }
      
    //Método para validar datos antes de la creación de un usuario, incluyendo la comprobación de alias y email duplicados
      public static void validarCreacion(String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular, int tipoUsuario) throws DatoInvalidoException {
        validar(nombre, apellido, alias, emailP, emailS, contrasenia, celular, tipoUsuario);
       
        //- si el alias ya esta registrado en un usuario, muestra un error de alias no disponible.
        Usuario usuario = Usuario.findFirst("alias = ?", alias);
        if (usuario != null) {
            throw new DatoInvalidoException("El alias " + alias + " no esta disponible.");
        }
        //- si el mail ya esta registrado en un usuario activo, muestra un error de email no disponible.
        usuario = Usuario.findFirst("email_principal = ?", emailP);
        if (usuario != null) {
            throw new DatoInvalidoException("El email principal " + emailP + " no esta disponible.");
        }
        
    }
    
    //Método para validar datos antes de la modificación de un usuario, incluyendo la comprobación de alias y email duplicados
    public static void validarModificacion(int id, String nombre, String apellido, String alias, String emailP, String emailS, String contrasenia, long celular, int tipoUsuario) throws DatoInvalidoException {
        validarUsuario(id);
        validar(nombre, apellido, alias, emailP, emailS, contrasenia, celular, tipoUsuario);
        //- si el mail o alias ya estan registrados en un usuario que no sea el que tiene el mismo id, muestra un error.
        Usuario usuario = Usuario.findFirst("email_principal = ? AND id <> ?", emailP, id);
        if (usuario != null) {
            throw new DatoInvalidoException("El email principal " + emailP + " no esta disponible.");
        }
        usuario = Usuario.findFirst("alias = ? AND id <> ?", alias, id);
        if (usuario != null) {
            throw new DatoInvalidoException("El alias " + alias + " no esta disponible.");
        }
        
    }
}
