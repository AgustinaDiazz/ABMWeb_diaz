/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

// Este es el controlador ListadoController para la gestión de usuarios y roles.
 

package app.controllers;
import app.exceptions.DatoInvalidoException;
import app.models.Rol;
import app.models.Usuario;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.javalite.activeweb.AppController;
import org.javalite.activeweb.annotations.DELETE;
import org.javalite.activeweb.annotations.POST;
import org.javalite.activeweb.annotations.PUT;
import org.javalite.common.JsonHelper;

 // Método para mostrar la lista de usuarios en la vista principal.

public class ListadoController extends AppController {
     public void index(){
        List<Usuario> usuarios = Usuario.listar();
        view("usuarios", usuarios);
    }
   // Método para preparar la creación de un nuevo usuario.
    public void crearUsuario(){
        List<Rol> roles = Rol.listar();
        view("roles", roles);
    }
     // Método para preparar la modificación de un usuario existente
    public void modificarUsuario(){
        Usuario datosUsuario = Usuario.obtenerUsuario(param("id"));
        List<Rol> roles = Rol.listar();
        view("roles", roles);
        view("usuario", datosUsuario);  
    }
    // Método para crear un nuevo usuario a través de una solicitud POST.
    @POST
    public void crear(){
        Map<String, String> errores = new HashMap<>();
        
    String nombre = param("nombre");
    String apellido = param("apellido");
    String alias = param("alias");
    String emailP = param("email_principal");
    String emailS = param("email_secundario");
    String contrasenia = param("contrasenia");
    String cel = param("nro_celular");
    
   //convertir el número de celular a un valor entero.
   try {
            long celular = Long.parseLong(cel);
            int tipoUsuario = Integer.parseInt(param("tipo"));
              
             // Validamos y creamos el usuario.
                Usuario.validarCreacion(nombre, apellido, alias, emailP, emailS, contrasenia, celular, tipoUsuario);
                Usuario.crear(nombre, apellido, alias, emailP, emailS, contrasenia, celular, tipoUsuario);
            // Ahora tienes nroCelular como un valor entero
        } catch(NumberFormatException | DatoInvalidoException e){
           errores.put("error", e.getMessage());
           respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
        return;
        }
        respond("");
    }
    
    // Método para modificar un usuario existente a través de una solicitud PUT.      
    @PUT
    public void modificar(){
        Map<String, String> errores = new HashMap<>();
        
        String nombre = param("nombre");
        String apellido = param("apellido");
        String alias = param("alias");
        String emailP = param("email_principal");
        String emailS = param("email_secundario");
        String contrasenia = param("contrasenia");
        try{
            long celular = Long.parseLong(param("nro_celular"));
            int tipoUsuario=Integer.parseInt(param("tipo"));
            int id=Integer.parseInt(param("id"));
            
             // Validamos y actualizamos los datos del usuario.
            Usuario.validarModificacion(id,nombre, apellido, alias, emailP, emailS, contrasenia, celular, tipoUsuario);
            Usuario.modificar(id, nombre, apellido, alias, emailP, emailS, contrasenia, celular, tipoUsuario);
        }catch(NumberFormatException | DatoInvalidoException e){
           errores.put("error", e.getMessage());
           respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
           
           return;
        }
        respond("");
        
    }
    
    // Método para eliminar un usuario a través de una solicitud DELETE.
    @DELETE
    public void borrar() {
        Map<String, String> errores = new HashMap<>();
        String alias="";
        
        // Recopilamos el ID del usuario a eliminar.
        String ids = param("id");
        try{
           int id=Integer.parseInt(ids);
           
           // Validamos y eliminamos al usuario.
           Usuario.validarUsuario(id);
           alias=Usuario.getAlias(id);
           Usuario.borrar(id);
        }catch(NumberFormatException | DatoInvalidoException e){
            errores.put("error", e.getMessage());
            //errores.put("error", "holis");
            respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
            
            return;
        }
        respond(alias);
     
    }
    // Método para ver los detalles de un usuario.
    public void ver(){
        Usuario usuario = Usuario.obtenerUsuario(param("id"));
        view("usuario", usuario);
    }
    
   
    
}
