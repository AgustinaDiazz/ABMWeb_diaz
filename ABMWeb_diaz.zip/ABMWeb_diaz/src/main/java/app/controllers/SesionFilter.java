/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controllers;


import org.javalite.activeweb.controller_filters.HttpSupportFilter;

public class SesionFilter extends HttpSupportFilter{
    
    @Override
    public void before() {
        if(!sessionHas("usuario")){
            String usuario=getHttpServletRequest().getRemoteUser();
            Boolean rol_ver = getHttpServletRequest().isUserInRole("ver");
            Boolean rol_abm = getHttpServletRequest().isUserInRole("ABM");
                
            if(rol_ver){
                if(rol_abm){
                    session("rol_abm", rol_abm);
                }
                session("rol_ver", rol_ver);
                session("usuario", usuario);
            }
        }
    }
}
